# agentic-workspace · Obsidian 联动模板

本库用于配合 Web 端「agentic-workspace」做双向联动。

## 目录结构
- 01_Daily/        日记（按 年/月 归档，如 2026/07）
- 02_Reflections/  深度思考文章（输出）：职场 / AI创业 / 个人成长
- 03_Thoughts/     思考积累（与 Web 端分类对应）：人生思考 / AI公众号文章 / AI工具积累 / 职场晋升
- 04_Templates/    模板：Daily.md / Reflection.md
- .obsidian/       插件配置（已内置，开箱即用）

## 使用步骤
1. 用 Obsidian 打开本文件夹作为仓库（仓库名建议设为 Main）。
2. 在「设置 → 关于」中确认仓库名为 Main（与 Web 端一致）。
3. 安装并启用 .obsidian 中列出的社区插件（Templater / Dataview / Calendar / Style Settings / Local REST API）。
4. Web 端「系统联动」页填写仓库名与（可选的）Local REST API Key。
5. 在日记 / 思考页点击「同步 Obsidian」即可唤起或写入对应笔记。

> 注意：Local REST API 需要在本机运行 Obsidian；纯远程网站无法直连，需本机常驻代理（超出纯前端范围，接口已预留）。
