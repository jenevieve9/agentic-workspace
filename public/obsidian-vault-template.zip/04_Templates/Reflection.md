---
title: 
date: {{date:YYYY-MM-DD}}
tags: [思考, 输出]
---

# 标题

## 核心观点
- 

## 论证 / 案例
- 

## 延伸联想
- 

## 关联思考积累
- [[03_Thoughts/xxx]]

## 下一步行动
- 
