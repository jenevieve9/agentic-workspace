---
date: {{date:YYYY-MM-DD}}
day: {{date:dddd}}
tags: [日记]
---

# {{date:YYYY-MM-DD}} · {{date:dddd}}

## 今日状态
- 情绪评分：___/10
- 精力评分：___/10
- 睡眠时长：___h

## 关键事件
- 

## 思考输出
- 

## 明日聚焦
- 

---
*关联思考积累：*
